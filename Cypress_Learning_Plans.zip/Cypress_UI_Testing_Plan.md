# Cypress UI Testing Learning Plan

## Milestones & Timeline

### Week 1: Setup & Basics
- Install Node.js & Cypress
- Understand Cypress folder structure
- Write first test for Google homepage

### Week 2: Core Cypress Features
- Commands (cy.get, cy.contains, cy.type, cy.click)
- Assertions (.should, expect)
- Test retries & waits

### Week 3: Advanced UI Testing
- Fixtures & test data
- Custom commands
- Page Object Model

### Week 4: Real-world Project
- Create UI tests for a demo e-commerce app (login, cart, checkout)
- Integrate Cypress Dashboard (optional)

### Practical Exercises
1. Automate Google search
2. Automate login form (valid & invalid cases)
3. Automate a shopping cart flow
