# Cypress API Testing Learning Plan

## Milestones & Timeline

### Week 1: API Basics with Cypress
- Learn about cy.request()
- GET, POST, PUT, DELETE requests
- Validate status codes & response bodies

### Week 2: JSON & Data Handling
- Validate JSON response schema
- Use fixtures for test data
- Chaining API requests

### Week 3: Advanced API Testing
- Authentication (Token & Basic Auth)
- Reusable API helpers
- Error handling tests

### Week 4: Real-world API Project
- Test a public API (e.g., Reqres, JSONPlaceholder)
- Build API regression suite

### Practical Exercises
1. Write GET test for users API
2. Write POST test to create user
3. Chain request: Create user → fetch user → delete user
